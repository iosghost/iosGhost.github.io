/*

GSMaps.h ... Graphics Service Maps.
 
Copyright (c) 2009, KennyTM~
All rights reserved.
 
Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 
 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the KennyTM~ nor the names of its contributors may be
   used to endorse or promote products derived from this software without
   specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
*/

#ifndef GSMAPS_H
#define GSMAPS_H

#include <Availability2.h>
#include <sys/cdefs.h>

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_3_1

#include <CoreFoundation/CoreFoundation.h>

__BEGIN_DECLS
/// Synchronize the com.apple.GMM preferences.
void GSUpdateMapsVisibilityPrefs();

/// Returns the MapKitUserShifting[Non]GreenTea setting from com.apple.GMM.
Boolean GSMapKitUserShifting();
/// Returns the MapsUserShifting[Non]GreenTea setting from com.apple.GMM.
Boolean GSMapsUserShifting();
/// Return true, or MapKitAvailableGreenTea setting from com.apple.GMM if the system has green-tea capability.
Boolean GSMapKitAvailable();
/// Returns true, or MapsVisibleGreenTea from com.apple.GMM if the system has green-tea capability.
/// This value will be refreshed when the carrier changes.
Boolean GSMapsVisible();

extern CFStringRef kGSMapsVisibilityChangedNotification;

__END_DECLS

#endif

#endif
