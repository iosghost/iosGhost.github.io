@protocol BSSettingDescriptionProvider

@end
