@protocol BSDescriptionProviding

@end
